<?php
return array (
  'template' => 'default',
  'baseControllerClass' => 'Controller',
);
